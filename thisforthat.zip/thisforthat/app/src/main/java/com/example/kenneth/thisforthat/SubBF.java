package com.example.kenneth.thisforthat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import static com.example.kenneth.thisforthat.Ingredients.contentRead1;

public class SubBF extends AppCompatActivity {
    private DatabaseHelper mySQLiteAdapter;
    public  static TextView data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_sub_bf);

        data = (TextView) findViewById(R.id.txtSub);
        TextView listContent = (TextView )findViewById(R.id.txtAPI);

        mySQLiteAdapter = new DatabaseHelper ();
        mySQLiteAdapter.getInstance ();
        mySQLiteAdapter.close();

        //ingredient's name ung parang title
        listContent.setText(contentRead1);

        fetchData process = new fetchData();
        process.execute();
    }
}


