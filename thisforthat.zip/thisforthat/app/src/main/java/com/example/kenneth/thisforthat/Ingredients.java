package com.example.kenneth.thisforthat;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import static com.example.kenneth.thisforthat.DatabaseHelper.*;

public class Ingredients extends ListActivity{
    Cursor cursor;
    SQLiteDatabase dh;
    CustomCursorAdapter myCursorAdapter;
    ContentValues values;
    public DatabaseHelper mySQLiteAdapter;
    public static String myString;
    public static String contentRead1;
    int buttonValue;
    public Dialog mDialog;
    public Button mDialogyes, mDialogno;

    //String sql = "INSERT INTO "+ TABLE_USERING +" SELECT _id, name, amount, selected FROM "+ TABLE_BF +" WHERE selected = 0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidContext.setContext(this);
        dh = DatabaseHelper.getInstance().getDb();
        values = new ContentValues();
        createDialog();

        buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        if (1 == buttonValue ) {
            bfListView ();
        }else if (2 == buttonValue){
            bmListView ();
        }else if (3 == buttonValue){
            bcListView ();
        }else if (4 == buttonValue){
            ccListView ();
        }else if (5 == buttonValue){
            cmListView ();
        }else if (6 == buttonValue){
            mcListView ();
        }else if (7 == buttonValue){
            rcListView ();
        }else if (8 == buttonValue){
            scListView ();
        }else if (9 == buttonValue){
            umListView ();
        }else if (10 == buttonValue){
            vcListView ();
        }
    }

    public void bfListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_BF, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);

        SharedPreferences prefs = this.getSharedPreferences(
                "TABLE_BF", Context.MODE_PRIVATE);
    }

    public void bcListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_BC, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void bmListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_BM, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void ccListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_CC, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void cmListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_CM, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void mcListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_MC, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void rcListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_RC, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void scListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_SC, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void umListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_UM, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    public void vcListView() {
        setContentView(R.layout.activity_ingredients);
        int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));

        cursor = dh.query(TABLE_VC, new String[]{"_id","name","amount","selected"}, null, null, null, null, "name asc");

        startManagingCursor(cursor);
        myCursorAdapter= new CustomCursorAdapter(this,cursor,buttonValue);
        this.getListView().setAdapter(myCursorAdapter);
    }

    protected void createDialog() {
        mDialog = new Dialog (this);
        mDialog.requestWindowFeature (Window.FEATURE_NO_TITLE);
        mDialog.setContentView (R.layout.dialog_exit);

        mDialog.setCanceledOnTouchOutside (true);
        mDialog.setCancelable (true);
        mDialogyes = ( Button ) mDialog.findViewById (R.id.yes);
        mDialogno = ( Button ) mDialog.findViewById (R.id.No);
        mDialogyes.setOnClickListener (new View.OnClickListener () {

            @Override
            public void onClick(View v) {
                int buttonValue = Integer.valueOf(getIntent ().getStringExtra("yourcode"));
                if (1 == buttonValue ) {
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllBF();
                    contentRead1 = mySQLiteAdapter.queueNameBF();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (2 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllBM();
                    contentRead1 = mySQLiteAdapter.queueNameBM();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (3 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllBC();
                    contentRead1 = mySQLiteAdapter.queueNameBC();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (4 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllCC ();
                    contentRead1 = mySQLiteAdapter.queueNameCC();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (5 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllCM();
                    contentRead1 = mySQLiteAdapter.queueNameCM();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (6 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllMC();
                    contentRead1 = mySQLiteAdapter.queueNameMC();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (7 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllRC();
                    contentRead1 = mySQLiteAdapter.queueNameRC();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (8 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllSC();
                    contentRead1 = mySQLiteAdapter.queueNameSC();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (9 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllUM();
                    contentRead1 = mySQLiteAdapter.queueNameUM();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }else if (10 == buttonValue){
                    //gets the name of the unchecked ingredients and put %20 on every space
                    mySQLiteAdapter = new DatabaseHelper ();
                    mySQLiteAdapter.getInstance ();
                    String contentRead = mySQLiteAdapter.queueAllVC();
                    contentRead1 = mySQLiteAdapter.queueNameVC();
                    mySQLiteAdapter.close();

                    myString = contentRead.replaceAll(" ", "%20");
                }
                startActivity(new Intent (Ingredients.this, SubBF.class));
            }
        });

        mDialogno.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
    }

    public void onBackPressed() {
        String sql = "UPDATE " +TABLE_BF+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql1 = "UPDATE " +TABLE_BC+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql2 = "UPDATE " +TABLE_BM+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql3 = "UPDATE " +TABLE_CC+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql4 = "UPDATE " +TABLE_CM+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql5 = "UPDATE " +TABLE_MC+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql6 = "UPDATE " +TABLE_RC+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql7 = "UPDATE " +TABLE_SC+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql8 = "UPDATE " +TABLE_UM+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";
        String sql9 = "UPDATE " +TABLE_VC+ " SET " +KEY_STATUS+ " = 0 WHERE " +KEY_STATUS+ " = 1";

        dh.execSQL (sql);
        dh.execSQL (sql1);
        dh.execSQL (sql2);
        dh.execSQL (sql3);
        dh.execSQL (sql4);
        dh.execSQL (sql5);
        dh.execSQL (sql6);
        dh.execSQL (sql7);
        dh.execSQL (sql8);
        dh.execSQL (sql9);

        startActivity(new Intent (Ingredients.this, MainActivity.class));
    }

    public void clickHandler(View view){

        if(view.getId() == R.id.checkbox){
            cursor.requery(); /* to get the updated values from sqlite on changing the check of checkbox*/
        }
    }

    public void onContinue(View view) {
        mDialog.show();
    }
}