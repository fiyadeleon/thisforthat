package com.example.kenneth.thisforthat;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import static com.example.kenneth.thisforthat.DatabaseHelper.TABLE_USERING;

public class LogoActivity extends AppCompatActivity {
    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logo);

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent (LogoActivity.this, MainActivity.class));
            }
        }, 1000); // 1 second
    }
}


